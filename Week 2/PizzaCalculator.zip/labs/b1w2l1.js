// begin hier je JavaScript commandos
